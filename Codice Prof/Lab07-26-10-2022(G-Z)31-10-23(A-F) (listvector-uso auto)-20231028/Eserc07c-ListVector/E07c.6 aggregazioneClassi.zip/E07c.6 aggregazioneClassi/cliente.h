#ifndef __CLIENTE_H__
#define __CLIENTE_H__
class Ordine;
#include <iostream>
#include <list>
#include "ordine.h"
using namespace std;


class Cliente{
private:
	int idCliente;
	list<Ordine*> lpo; 
public:	
	Cliente(int id);
	~Cliente();
	void addOrdine(Ordine* po);
	void stampa()const;
	friend ostream& operator << (ostream& os, const Cliente& c);
};

ostream& operator << (ostream& os, const Cliente& c);


#endif

