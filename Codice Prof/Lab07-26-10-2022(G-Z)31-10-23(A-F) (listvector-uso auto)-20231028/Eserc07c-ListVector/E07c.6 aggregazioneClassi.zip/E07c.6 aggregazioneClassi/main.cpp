#include <iostream>
#include "ordine.h"
#include "cliente.h"
using namespace std;

int main(int argc, char** argv) {
	{
		Ordine o1(1), o2(2), o3(3);
		//cout << o1 << endl;
		//o2.stampa();
		Cliente c1(1);
		c1.addOrdine(&o1);
		c1.addOrdine(&o2);
		c1.addOrdine(&o3);
		c1.stampa();
		cout << c1 << endl;
	}
	return 0;
}
