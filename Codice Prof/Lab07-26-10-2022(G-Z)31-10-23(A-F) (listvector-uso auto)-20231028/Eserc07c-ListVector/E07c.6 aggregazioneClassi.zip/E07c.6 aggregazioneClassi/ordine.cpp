#include <iostream>
#include "ordine.h"
using namespace std;

Ordine::Ordine(int id){
	idOrdine = id;
	pc = NULL;
	cout << "Ordine creato ID=" << idOrdine << endl;
}
Ordine::~Ordine(){
	cout << "Ordine distrutto ID=" << idOrdine << endl;
}
void Ordine::setCliente(Cliente* c){
	pc = c;	
}
void Ordine::stampa()const{
	cout << "[ID=" << idOrdine << "]";
}
ostream& operator << (ostream& os,  Ordine& o){
	//os << *(o.pc) << endl;
	//(*(o.pc).stampa();
	os << "[ID=" << o.idOrdine << "]";
	return os;		
}

