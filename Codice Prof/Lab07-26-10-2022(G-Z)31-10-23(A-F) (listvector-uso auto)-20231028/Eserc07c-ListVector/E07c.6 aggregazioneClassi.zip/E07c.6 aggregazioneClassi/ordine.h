#ifndef __ORDINE_H__
#define __ORDINE_H__

class Cliente;
#include <iostream>
#include "cliente.h"
using namespace std;

class Ordine{
private:
	int idOrdine;
	Cliente *pc;
public:	
	Ordine(int id);
	~Ordine();
	void setCliente(Cliente* c);
	void stampa()const;
	friend ostream& operator << (ostream& os,  Ordine& o);
};

ostream& operator << (ostream& os,  Ordine& o);

#endif

