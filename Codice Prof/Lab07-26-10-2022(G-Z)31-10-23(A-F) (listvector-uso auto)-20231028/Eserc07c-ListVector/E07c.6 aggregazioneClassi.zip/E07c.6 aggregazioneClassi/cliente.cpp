#include <iostream>
#include "cliente.h"
using namespace std;

Cliente::Cliente(int id){
	idCliente = id;
	cout << "Cliente creato ID=" << idCliente << endl;
}
Cliente::~Cliente(){
	cout << "Cliente distrutto ID=" << idCliente << endl;
}
	
void Cliente::stampa()const{  
	//se si usa iterator non ci va il const!!!!
	cout << "IDcliente=" << idCliente << endl;
	//scorrro la lista in ordine
	list<Ordine*>::const_iterator il;
	for(il=lpo.begin(); il!=lpo.end(); ++il){
		cout << *(*il);	
	}
	cout << endl;
}

void Cliente::addOrdine(Ordine* po){
	//lpo.push_back(po);	//in coda alla lista
	lpo.push_front(po);		//in testa alla lista
	//per la navigabilit�
	po->setCliente(this);
}

ostream& operator << (ostream& os, const Cliente& c){
	//se si usa reverse_iterator o iterator non ci va il const!!!!
	os << "IDcliente=" << c.idCliente << endl;
	list<Ordine*>::const_reverse_iterator ril;
	for(ril=c.lpo.rbegin(); ril!=c.lpo.rend(); ++ril){
		os << **ril;		
	}
	return os;
}
